import React from 'react';
// import './Login.css';

const Cart = () => {
  return (
    <div>CArt</div>
  );
};

export default Cart;