// src/components/Login.js

import React from 'react';
import './Login.css';
import { Link } from 'react-router-dom';

const Login = () => {
  return (
    <div>
      {/* Navigation Bar */}
      <nav>
        <div className="logo">
          <h1>E-commerce</h1>
        </div>
        <ul className="nav-links">
          <li><Link to="/">Home</Link></li>
          <li><Link to="/products">Products</Link></li>
          <li><Link to="/cart">Cart</Link></li>
          <li><Link to="/login">Login</Link></li>
        </ul>
      </nav>
    <div className="login-container">
      <div className="login-box">
        <h2>Login</h2>
        <div className="option-container">
          <Link to="/loginAdmin" className="link-button">
          <button className="admin-option">Admin</button>
          </Link>
          <Link to="/loginUser" className="link-button">
          <button className="user-option">User</button>
          </Link>
        </div>
        <Link to="/Signup" className="link-button">
        <button className="signup-button">Sign Up</button>
        </Link>
      </div>
    </div>
    </div>
  );
};

export default Login;
