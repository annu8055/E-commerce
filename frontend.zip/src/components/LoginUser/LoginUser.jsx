// src/components/Login.js

import React from 'react';
import "./LoginUser.css"

const LoginUser = () => {
  return (
    <div className="login-container">
      <h2>User Login</h2>
      <form>
        <div className="form-group">
          <label htmlFor="email">Email</label>
          <input type="email" id="email" />
        </div>
        <div className="form-group">
          <label htmlFor="password">Password</label>
          <input type="password" id="password" />
        </div>
        <button type="submit">Login</button>
      </form>
    </div>
  );
};

export default LoginUser;
