// src/components/Home.js

import React from "react";
import ProductList from "../ProductList/ProductList";
import "./Home.css";
import { Link } from "react-router-dom";
import banner from "../../banner.jpg";
import linkdin from "../../linkedin.svg";

const Home = () => {
  return (
    <div className="navBar">
      {/* Navigation Bar */}
      <nav>
        <div className="logo">
          <h1>E-commerce</h1>
        </div>
        <ul className="nav-links">
          <li>
            <Link to="/">Home</Link>
          </li>
          <li>
            <Link to="/products">Products</Link>
          </li>
          <li>
            <Link to="/cart">Cart</Link>
          </li>
          <li>
            <Link to="/login">Login</Link>
          </li>
        </ul>
      </nav>

      {/* Hero Section */}
      <div className="hero">

      <img src={banner} className="banner" alt="Netflix" />
        
        {/* Featured Products */}
      <section className="featured-products">
        <h2>Featured Products</h2>
        <ProductList />
      </section>
        <Link to="/products" className="link-button">
        <button>Shop Now</button>
        </Link>
        <h2>Welcome to Our E-commerce Store!</h2>
        <p>Discover a world of incredible products and a seamless shopping experience right at your fingertips. We are thrilled to introduce our new online platform that brings you a wide range of high-quality products, from the latest gadgets and electronics to trendy fashion and home essentials.</p>
        <p>At our E-commerce store, we pride ourselves on offering an extensive collection of products that cater to all your needs. Whether you are searching for the perfect gift, upgrading your tech gadgets, or adding a touch of style to your wardrobe, we have something for everyone.</p>
        <p>Why shop with us? Our commitment to exceptional customer service and user-friendly navigation makes your shopping journey enjoyable and effortless. Explore our intuitive website, easily browse through categories, and discover new products from top brands.</p>
        <p>Our dedicated team is always working behind the scenes to bring you the best deals and discounts, ensuring you get the most value for your money. Plus, with our secure payment gateway, you can shop with confidence, knowing your personal information is safe and protected.</p>
        <p>Stay ahead of the latest trends and never miss out on exclusive offers by signing up for our newsletter. Be the first to know about new arrivals, limited-time promotions, and exciting sales events.</p>
        <p> Stay ahead of the latest trends and never miss out on exclusive offers by signing up for our newsletter. Be the first to know about new arrivals, limited-time promotions, and exciting sales events.
         We take pride in delivering a seamless shopping experience to our customers, so you can focus on what matters most - finding the perfect products that enhance your life.</p>
         <p>Thank you for choosing us as your preferred online shopping destination. Happy shopping!</p>
      </div>

     

     

      {/* Footer */}
      <footer>
        <p>&copy; 2023 E-commerce. All rights reserved.</p>
        <b>Anup Yadav </b> 
        <Link to="https://www.linkedin.com/in/anup-yadav-377807148">
        <img src={linkdin} className="linkedin" alt="linkdin" />
        </Link>
      </footer>
    </div>
  );
};

export default Home;
