import React from "react";
import ReactDOM from "react-dom/client";
import App from "./App";
// import { AuthContextProvider } from "./context/authContext";
// import { DarkModeContextProvider } from "./context/darkModeContext";

const root = ReactDOM.createRoot(document.getElementById("root"));
root.render(
  <React.StrictMode>
    {/* <DarkModeContextProvider> */}
      {/* <AuthContextProvider> */}
        <App />
      {/* </AuthContextProvider> */}
    {/* </DarkModeContextProvider> */}
  </React.StrictMode>
);

// src/index.js

// import React from 'react';
// import ReactDOM from 'react-dom';
// import { BrowserRouter } from 'react-router-dom';
// import App from './App';

// ReactDOM.render(
//   <BrowserRouter>
//     <App />
//   </BrowserRouter>,
//   document.getElementById('root')
// );
