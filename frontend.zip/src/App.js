// src/App.js

import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Home from './components/Home/Home';
import Login from './components/Login/Login';
import Products from './components/Products/Products';
import Cart from './components/Cart/Cart';
import Signup from './components/Signup/Signup';
import './components/Signup/Signup.css'; 
import LoginUser from './components/LoginUser/LoginUser';
import LoginAdmin from './components/LoginAdmin/LoginAdmin';
import './components/LoginUser/LoginUser.css'; 
import './components/LoginAdmin/LoginAdmin.css'; 

function App() {
  return (
    <Router>
      <Routes>
        {/* Route to Home page */}
        <Route path="/" element={<Home />} />

        {/* Route to Login page */}
        <Route path="/login" element={<Login />} />

        {/* Route to Products page */}
        <Route path="/products" element={<Products />} />

        {/* Route to Cart page */}
        <Route path="/cart" element={<Cart />} />

        {/* Route to Signup page */}
        <Route path="/signup" element={<Signup />} />

        {/* Route to Login page */}
        <Route path="/loginUser" element={<LoginUser />} />

        {/* Route to Login page */}
        <Route path="/loginAdmin" element={<LoginAdmin />} />
        
        {/* Add more routes for other pages */}
      </Routes>
    </Router>
  );
}

export default App;
